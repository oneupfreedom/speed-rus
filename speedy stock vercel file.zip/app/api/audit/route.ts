import { NextResponse, type NextRequest } from 'next/server'
import { auditToken, detectChain, isChain } from '@/lib/dexscreener'

export async function GET(req: NextRequest) {
  const address = req.nextUrl.searchParams.get('address')?.trim() ?? ''
  const chainParam = req.nextUrl.searchParams.get('chain')
  const chain = isChain(chainParam) ? chainParam : detectChain(address)

  if (!chain || !detectChain(address)) {
    return NextResponse.json(
      { error: 'Invalid contract address. Paste a Solana mint or Base (0x…) token address.' },
      { status: 400 },
    )
  }

  const token = await auditToken(chain, address)
  if (!token) {
    return NextResponse.json(
      { error: `No active ${chain === 'base' ? 'Base' : 'Solana'} pairs found for this address.` },
      { status: 404 },
    )
  }
  return NextResponse.json({ token })
}
