import { NextResponse } from 'next/server'
import { scanFreshTokens } from '@/lib/dexscreener'
import { MAX_PAIR_AGE_MS } from '@/lib/scanner'

export async function GET() {
  const tokens = await scanFreshTokens(MAX_PAIR_AGE_MS)
  return NextResponse.json({ tokens, scannedAt: Date.now() })
}
