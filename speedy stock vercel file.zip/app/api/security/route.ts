import { NextResponse, type NextRequest } from 'next/server'
import { detectChain, isChain } from '@/lib/dexscreener'
import { getSecurityReport } from '@/lib/security'

export async function GET(req: NextRequest) {
  const address = req.nextUrl.searchParams.get('address')?.trim() ?? ''
  const chainParam = req.nextUrl.searchParams.get('chain')
  const detected = detectChain(address)
  const chain = isChain(chainParam) ? chainParam : detected

  if (!chain || !detected || detected !== chain) {
    return NextResponse.json({ error: 'Invalid chain or contract address.' }, { status: 400 })
  }

  const report = await getSecurityReport(chain, address)
  return NextResponse.json({ report })
}
