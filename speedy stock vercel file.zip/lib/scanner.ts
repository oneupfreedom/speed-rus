export type Chain = 'solana' | 'base'

export interface TokenMetrics {
  chain: Chain
  address: string
  pairAddress: string
  name: string
  symbol: string
  imageUrl: string | null
  url: string
  dexId: string
  priceUsd: number
  marketCap: number
  liquidityUsd: number
  volumeM5: number
  volumeH1: number
  volumeH24: number
  buysM5: number
  sellsM5: number
  buysH1: number
  sellsH1: number
  priceChangeH1: number
  priceChangeH24: number
  pairCreatedAt: number | null
  top10Pct: number | null
}

export type GateStatus = 'pass' | 'warn' | 'fail'

export interface GateCheck {
  label: string
  value: string
  status: GateStatus
}

export interface GateResult {
  id: number
  name: string
  criteria: string
  status: GateStatus
  headline: string
  checks: GateCheck[]
}

export type Verdict = 'green' | 'yellow' | 'red'
export type Speed = 'high' | 'moderate'

export const MAX_PAIR_AGE_MS = 24 * 60 * 60 * 1000
export const HIGH_SPEED_VOL_MC = 1.2

export function volMcRatio(t: TokenMetrics) {
  return t.marketCap > 0 ? t.volumeH24 / t.marketCap : 0
}

export function buyRatio(buys: number, sells: number) {
  const total = buys + sells
  return total > 0 ? buys / total : 0
}

function combine(statuses: GateStatus[]): GateStatus {
  const passes = statuses.filter((s) => s === 'pass').length
  if (passes === statuses.length) return 'pass'
  if (statuses.includes('fail') && passes < statuses.length - 1) return 'fail'
  return 'warn'
}

export function evaluateGates(t: TokenMetrics, top10Override?: number | null): GateResult[] {
  const mc = t.marketCap
  const volMc = volMcRatio(t)
  const buyPct = buyRatio(t.buysH1, t.sellsH1)
  const liqPct = mc > 0 ? t.liquidityUsd / mc : 0
  const top10 = top10Override ?? t.top10Pct
  const txnsM5 = t.buysM5 + t.sellsM5

  const g1Status: GateStatus =
    mc >= 500_000 && mc <= 1_800_000
      ? 'pass'
      : (mc >= 350_000 && mc < 500_000) || (mc > 1_800_000 && mc <= 2_500_000)
        ? 'warn'
        : 'fail'

  const g2Checks: GateCheck[] = [
    {
      label: 'Vol/MC (24h) ≥ 1.0',
      value: `${volMc.toFixed(2)}x`,
      status: volMc >= 1 ? 'pass' : volMc >= 0.7 ? 'warn' : 'fail',
    },
    {
      label: '1h Volume ≥ $500K',
      value: formatUsd(t.volumeH1),
      status: t.volumeH1 >= 500_000 ? 'pass' : t.volumeH1 >= 250_000 ? 'warn' : 'fail',
    },
    {
      label: 'Buy-side flow > 60% (1h txns)',
      value: `${(buyPct * 100).toFixed(0)}%`,
      status: buyPct > 0.6 ? 'pass' : buyPct >= 0.5 ? 'warn' : 'fail',
    },
  ]

  const g3Checks: GateCheck[] = [
    {
      label: 'LP ≥ 12% of MC',
      value: `${(liqPct * 100).toFixed(1)}%`,
      status: liqPct >= 0.12 ? 'pass' : liqPct >= 0.08 ? 'warn' : 'fail',
    },
    {
      label: 'or LP ≥ $80K',
      value: formatUsd(t.liquidityUsd),
      status: t.liquidityUsd >= 80_000 ? 'pass' : t.liquidityUsd >= 50_000 ? 'warn' : 'fail',
    },
  ]
  const g3Status: GateStatus = g3Checks.some((c) => c.status === 'pass')
    ? 'pass'
    : g3Checks.some((c) => c.status === 'warn')
      ? 'warn'
      : 'fail'

  const g4Status: GateStatus =
    top10 == null ? 'warn' : top10 < 20 ? 'pass' : top10 < 30 ? 'warn' : 'fail'

  const g5Checks: GateCheck[] = [
    {
      label: 'Buyers/hr > 200 (buy txns)',
      value: t.buysH1.toLocaleString('en-US'),
      status: t.buysH1 > 200 ? 'pass' : t.buysH1 > 100 ? 'warn' : 'fail',
    },
    {
      label: 'Txn velocity ≥ 20 / 5m',
      value: txnsM5.toLocaleString('en-US'),
      status: txnsM5 >= 20 ? 'pass' : txnsM5 >= 8 ? 'warn' : 'fail',
    },
  ]

  return [
    {
      id: 1,
      name: 'Market Cap',
      criteria: '$500K – $1.8M sweet spot (2x runway)',
      status: g1Status,
      headline: formatUsd(mc),
      checks: [{ label: 'In $500K – $1.8M band', value: formatUsd(mc), status: g1Status }],
    },
    {
      id: 2,
      name: 'Volume Velocity',
      criteria: 'Vol/MC ≥ 1.0 · 1h Vol ≥ $500K · >60% buys',
      status: combine(g2Checks.map((c) => c.status)),
      headline: `${volMc.toFixed(2)}x Vol/MC`,
      checks: g2Checks,
    },
    {
      id: 3,
      name: 'Liquidity Depth',
      criteria: 'LP ≥ 12% of MC or ≥ $80K',
      status: g3Status,
      headline: formatUsd(t.liquidityUsd),
      checks: g3Checks,
    },
    {
      id: 4,
      name: 'Holder Risk',
      criteria: 'Top 10 holders < 20% of supply',
      status: g4Status,
      headline: top10 == null ? 'Unverified' : `${top10.toFixed(1)}%`,
      checks: [
        {
          label: 'Top 10 concentration < 20%',
          value: top10 == null ? 'No data' : `${top10.toFixed(1)}%`,
          status: g4Status,
        },
      ],
    },
    {
      id: 5,
      name: 'Buyer Acceleration',
      criteria: '>200 buyers/hr + active txn velocity',
      status: combine(g5Checks.map((c) => c.status)),
      headline: `${t.buysH1.toLocaleString('en-US')} buys/hr`,
      checks: g5Checks,
    },
  ]
}

export interface SecurityReport {
  chain: Chain
  source: 'RugCheck' | 'GoPlus'
  reportUrl: string
  available: boolean
  lpLockedPct: number | null
  mintRevoked: boolean | null
  freezeRevoked: boolean | null
  ownerRenounced: boolean | null
  insiderPct: number | null
  insiderNetworks: number | null
  honeypot: boolean | null
  sellTaxPct: number | null
  dangerFlags: string[]
  top10Pct: number | null
  totalHolders: number | null
}

const UNKNOWN: GateCheck['status'] = 'warn'

function authorityCheck(label: string, revoked: boolean | null, okText: string, badText: string): GateCheck {
  return {
    label,
    value: revoked == null ? 'Unknown' : revoked ? okText : badText,
    status: revoked == null ? UNKNOWN : revoked ? 'pass' : 'fail',
  }
}

export function evaluateSecurity(report: SecurityReport | null | undefined, chain: Chain): GateResult {
  const base = {
    id: 6,
    name: 'Security & Integrity',
    criteria:
      chain === 'solana'
        ? 'LP burned/locked · mint + freeze revoked · clusters < 15%'
        : 'LP burned/locked · no mint · renounced · no honeypot',
  }

  if (!report?.available) {
    return {
      ...base,
      status: 'warn',
      headline: report === undefined ? 'Checking…' : 'Unverified',
      checks: [
        {
          label: `${chain === 'solana' ? 'RugCheck' : 'GoPlus'} report`,
          value: report === undefined ? 'Loading' : 'Unavailable',
          status: 'warn',
        },
      ],
    }
  }

  const lp = report.lpLockedPct
  const checks: GateCheck[] = [
    {
      label: 'Liquidity pool burned / locked',
      value: lp == null ? 'No pool data' : `${lp.toFixed(0)}%`,
      status: lp == null ? UNKNOWN : lp >= 95 ? 'pass' : lp >= 50 ? 'warn' : 'fail',
    },
    authorityCheck(
      chain === 'solana' ? 'Mint authority' : 'Mint function',
      report.mintRevoked,
      chain === 'solana' ? 'Revoked' : 'Disabled',
      'Active',
    ),
  ]

  if (chain === 'solana') {
    checks.push(authorityCheck('Freeze authority', report.freezeRevoked, 'Revoked', 'Active'))
    const ins = report.insiderPct
    checks.push({
      label: 'Bundle / insider cluster < 15%',
      value:
        ins == null
          ? 'Unknown'
          : `${ins.toFixed(1)}%${report.insiderNetworks ? ` · ${report.insiderNetworks} net` : ''}`,
      status: ins == null ? UNKNOWN : ins < 15 ? 'pass' : ins < 25 ? 'warn' : 'fail',
    })
  } else {
    checks.push({
      label: 'Ownership renounced',
      value: report.ownerRenounced == null ? 'Unknown' : report.ownerRenounced ? 'Renounced' : 'Owner active',
      status: report.ownerRenounced == null ? UNKNOWN : report.ownerRenounced ? 'pass' : 'warn',
    })
    const tax = report.sellTaxPct
    checks.push({
      label: 'Honeypot / sell tax ≤ 5%',
      value: report.honeypot ? 'HONEYPOT' : tax == null ? 'Unknown' : `${tax.toFixed(1)}% tax`,
      status: report.honeypot ? 'fail' : tax == null ? UNKNOWN : tax <= 5 ? 'pass' : tax <= 10 ? 'warn' : 'fail',
    })
  }

  if (report.dangerFlags.length) {
    checks.push({
      label: `${report.source} danger flags`,
      value: `${report.dangerFlags[0]}${report.dangerFlags.length > 1 ? ` +${report.dangerFlags.length - 1}` : ''}`,
      status: 'fail',
    })
  }

  const statuses = checks.map((c) => c.status)
  const status: GateStatus = statuses.includes('fail') ? 'fail' : statuses.every((s) => s === 'pass') ? 'pass' : 'warn'
  const passed = statuses.filter((s) => s === 'pass').length

  return { ...base, status, headline: `${passed}/${checks.length} clean`, checks }
}

export const RUG_PASS_BELOW = 50
const RUG_MIN_SAMPLE_TXNS = 10

export interface RugRule {
  id: 'liquidity' | 'holders' | 'sellPressure'
  label: string
  threshold: string
  value: string
  points: number
  triggered: boolean
  severity: 'critical' | 'warning'
  message: string | null
  unverified?: boolean
}

export interface RugResult {
  passed: boolean
  riskScore: number
  rules: RugRule[]
  warnings: string[]
}

export function evaluateRugRisk(t: TokenMetrics, top10Pct: number | null): RugResult {
  const liqRatio = t.marketCap > 0 ? t.liquidityUsd / t.marketCap : 0
  const liqHit = liqRatio < 0.05

  const holdersHit = top10Pct != null && top10Pct > 25

  const txnsM5 = t.buysM5 + t.sellsM5
  const sellRatio = txnsM5 > 0 ? t.sellsM5 / txnsM5 : 0
  const sellHit = txnsM5 >= RUG_MIN_SAMPLE_TXNS && sellRatio > 0.65 && t.sellsM5 > t.buysM5

  const rules: RugRule[] = [
    {
      id: 'liquidity',
      label: 'Liquidity / FDV',
      threshold: '≥ 5%',
      value: `${(liqRatio * 100).toFixed(1)}%`,
      points: 40,
      triggered: liqHit,
      severity: 'critical',
      message: liqHit ? 'Low liquidity relative to FDV (high slippage / dump risk)' : null,
    },
    {
      id: 'holders',
      label: 'Top 10 holders',
      threshold: '≤ 25%',
      value: top10Pct == null ? 'Unverified' : `${top10Pct.toFixed(1)}%`,
      points: 50,
      triggered: holdersHit,
      severity: 'critical',
      message: holdersHit ? `High whale / insider concentration (${top10Pct!.toFixed(1)}%)` : null,
      unverified: top10Pct == null,
    },
    {
      id: 'sellPressure',
      label: 'Sell pressure (5m txns)',
      threshold: '≤ 65% sells',
      value: txnsM5 === 0 ? 'No trades' : `${Math.round(sellRatio * 100)}% · ${t.sellsM5}/${txnsM5}`,
      points: 45,
      triggered: sellHit,
      severity: 'warning',
      message: sellHit ? 'Sudden surge in sell velocity outpacing buys' : null,
    },
  ]

  const riskScore = rules.reduce((sum, r) => sum + (r.triggered ? r.points : 0), 0)
  return {
    passed: riskScore < RUG_PASS_BELOW,
    riskScore,
    rules,
    warnings: rules.flatMap((r) => (r.message ? [`${r.severity.toUpperCase()}: ${r.message}`] : [])),
  }
}

export function getVerdict(gates: GateResult[], rug?: RugResult): Verdict {
  if (rug && !rug.passed) return 'red'
  if (gates.some((g) => g.status === 'fail')) return 'red'
  if (gates.every((g) => g.status === 'pass')) return 'green'
  return 'yellow'
}

export function getSpeed(t: TokenMetrics): Speed {
  return volMcRatio(t) >= HIGH_SPEED_VOL_MC ? 'high' : 'moderate'
}

export function formatUsd(n: number) {
  if (!Number.isFinite(n)) return '—'
  const abs = Math.abs(n)
  if (abs >= 1e9) return `$${(n / 1e9).toFixed(2)}B`
  if (abs >= 1e6) return `$${(n / 1e6).toFixed(2)}M`
  if (abs >= 1e3) return `$${(n / 1e3).toFixed(1)}K`
  return `$${n.toFixed(0)}`
}

export function formatPrice(n: number) {
  if (!Number.isFinite(n) || n === 0) return '—'
  if (n >= 1) return `$${n.toFixed(4)}`
  const digits = Math.min(12, Math.max(4, -Math.floor(Math.log10(n)) + 3))
  return `$${n.toFixed(digits)}`
}

export function formatAge(createdAt: number | null, now = Date.now()) {
  if (!createdAt) return '—'
  const mins = Math.max(0, Math.floor((now - createdAt) / 60000))
  if (mins < 60) return `${mins}m`
  const hours = Math.floor(mins / 60)
  if (hours < 48) return `${hours}h ${mins % 60}m`
  return `${Math.floor(hours / 24)}d`
}

export function shortAddress(a: string) {
  return a.length > 12 ? `${a.slice(0, 4)}…${a.slice(-4)}` : a
}
