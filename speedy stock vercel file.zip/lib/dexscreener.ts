import 'server-only'
import type { Chain, TokenMetrics } from './scanner'

const API = 'https://api.dexscreener.com'
const CHAINS: Chain[] = ['solana', 'base']

interface DexPair {
  chainId: string
  dexId: string
  url: string
  pairAddress: string
  baseToken: { address: string; name: string; symbol: string }
  priceUsd?: string
  txns?: Record<string, { buys: number; sells: number }>
  volume?: Record<string, number>
  priceChange?: Record<string, number>
  liquidity?: { usd?: number }
  fdv?: number
  marketCap?: number
  pairCreatedAt?: number
  info?: { imageUrl?: string }
}

interface TokenRef {
  chainId: string
  tokenAddress: string
}

export function isChain(v: unknown): v is Chain {
  return v === 'solana' || v === 'base'
}

export function detectChain(address: string): Chain | null {
  if (/^0x[a-fA-F0-9]{40}$/.test(address)) return 'base'
  if (/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(address)) return 'solana'
  return null
}

async function getJson<T>(url: string, revalidate = 15): Promise<T | null> {
  try {
    const res = await fetch(url, {
      next: { revalidate },
      headers: { accept: 'application/json' },
      signal: AbortSignal.timeout(8000),
    })
    if (!res.ok) return null
    return (await res.json()) as T
  } catch {
    return null
  }
}

function toMetrics(pair: DexPair): TokenMetrics {
  const tx = pair.txns ?? {}
  const vol = pair.volume ?? {}
  return {
    chain: pair.chainId as Chain,
    address: pair.baseToken.address,
    pairAddress: pair.pairAddress,
    name: pair.baseToken.name,
    symbol: pair.baseToken.symbol,
    imageUrl: pair.info?.imageUrl ?? null,
    url: pair.url,
    dexId: pair.dexId,
    priceUsd: Number(pair.priceUsd ?? 0),
    marketCap: pair.marketCap ?? pair.fdv ?? 0,
    liquidityUsd: pair.liquidity?.usd ?? 0,
    volumeM5: vol.m5 ?? 0,
    volumeH1: vol.h1 ?? 0,
    volumeH24: vol.h24 ?? 0,
    buysM5: tx.m5?.buys ?? 0,
    sellsM5: tx.m5?.sells ?? 0,
    buysH1: tx.h1?.buys ?? 0,
    sellsH1: tx.h1?.sells ?? 0,
    priceChangeH1: pair.priceChange?.h1 ?? 0,
    priceChangeH24: pair.priceChange?.h24 ?? 0,
    pairCreatedAt: pair.pairCreatedAt ?? null,
    top10Pct: null,
  }
}

function bestPairs(pairs: DexPair[]): Map<string, DexPair> {
  const best = new Map<string, DexPair>()
  for (const p of pairs) {
    const key = `${p.chainId}:${p.baseToken.address.toLowerCase()}`
    const current = best.get(key)
    if (!current || (p.liquidity?.usd ?? 0) > (current.liquidity?.usd ?? 0)) best.set(key, p)
  }
  return best
}

async function fetchTokens(chain: Chain, addresses: string[]): Promise<DexPair[]> {
  const chunks: string[][] = []
  for (let i = 0; i < addresses.length; i += 30) chunks.push(addresses.slice(i, i + 30))
  const results = await Promise.all(
    chunks.map((c) => getJson<DexPair[]>(`${API}/tokens/v1/${chain}/${c.join(',')}`)),
  )
  return results.flatMap((r) => r ?? [])
}

export async function scanFreshTokens(maxAgeMs: number): Promise<TokenMetrics[]> {
  const sources = await Promise.all([
    getJson<TokenRef[]>(`${API}/token-profiles/latest/v1`),
    getJson<TokenRef[]>(`${API}/token-boosts/latest/v1`),
    getJson<TokenRef[]>(`${API}/token-boosts/top/v1`),
  ])

  const byChain = new Map<Chain, Set<string>>(CHAINS.map((c) => [c, new Set()]))
  for (const ref of sources.flatMap((s) => s ?? [])) {
    if (isChain(ref.chainId)) byChain.get(ref.chainId)!.add(ref.tokenAddress)
  }

  const pairs = (
    await Promise.all(CHAINS.map((c) => fetchTokens(c, [...byChain.get(c)!])))
  ).flat()

  const now = Date.now()
  return [...bestPairs(pairs).values()]
    .map(toMetrics)
    .filter((t) => t.pairCreatedAt != null && now - t.pairCreatedAt <= maxAgeMs && t.marketCap > 0)
}

export async function auditToken(chain: Chain, address: string): Promise<TokenMetrics | null> {
  const pairs = await getJson<DexPair[]>(`${API}/tokens/v1/${chain}/${address}`, 10)
  if (!pairs?.length) return null
  const pair = bestPairs(pairs).values().next().value
  if (!pair) return null
  const metrics = toMetrics(pair)
  if (chain === 'solana') metrics.top10Pct = await solanaTop10Pct(address)
  return metrics
}

async function solanaRpc<T>(method: string, params: unknown[]): Promise<T | null> {
  try {
    const res = await fetch(process.env.SOLANA_RPC_URL ?? 'https://api.mainnet-beta.solana.com', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
      signal: AbortSignal.timeout(5000),
      cache: 'no-store',
    })
    const json = (await res.json()) as { result?: T }
    return json.result ?? null
  } catch {
    return null
  }
}

async function solanaTop10Pct(mint: string): Promise<number | null> {
  const [largest, supply] = await Promise.all([
    solanaRpc<{ value: { uiAmount: number | null }[] }>('getTokenLargestAccounts', [mint]),
    solanaRpc<{ value: { uiAmount: number | null } }>('getTokenSupply', [mint]),
  ])
  const total = supply?.value.uiAmount ?? 0
  if (!largest || total <= 0) return null
  const top10 = largest.value.slice(0, 10).reduce((sum, a) => sum + (a.uiAmount ?? 0), 0)
  return (top10 / total) * 100
}
