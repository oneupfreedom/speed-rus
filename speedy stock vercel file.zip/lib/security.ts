import 'server-only'
import type { Chain, SecurityReport } from './scanner'

const BURN_ADDRESSES = new Set([
  '0x000000000000000000000000000000000000dead',
  '0x0000000000000000000000000000000000000000',
])

async function getJson<T>(url: string): Promise<T | null> {
  try {
    const res = await fetch(url, {
      next: { revalidate: 60 },
      headers: { accept: 'application/json' },
      signal: AbortSignal.timeout(9000),
    })
    if (!res.ok) return null
    return (await res.json()) as T
  } catch {
    return null
  }
}

function emptyReport(chain: Chain, address: string): SecurityReport {
  return {
    chain,
    source: chain === 'solana' ? 'RugCheck' : 'GoPlus',
    reportUrl: reportUrl(chain, address),
    available: false,
    lpLockedPct: null,
    mintRevoked: null,
    freezeRevoked: null,
    ownerRenounced: null,
    insiderPct: null,
    insiderNetworks: null,
    honeypot: null,
    sellTaxPct: null,
    dangerFlags: [],
    top10Pct: null,
    totalHolders: null,
  }
}

function reportUrl(chain: Chain, address: string) {
  return chain === 'solana'
    ? `https://rugcheck.xyz/tokens/${address}`
    : `https://gopluslabs.io/token-security/8453/${address}`
}

interface RugReport {
  mint?: string
  mintAuthority: string | null
  freezeAuthority: string | null
  risks?: { name: string; level: string }[] | null
  markets?: { lp?: { lpLockedPct?: number; quoteUSD?: number; baseUSD?: number } | null }[] | null
  topHolders?: { address: string; owner: string; pct: number; insider?: boolean }[] | null
  knownAccounts?: Record<string, { name: string; type: string }> | null
  insiderNetworks?: unknown[] | null
  graphInsidersDetected?: number
  totalHolders?: number
}

async function solanaSecurity(mint: string): Promise<SecurityReport> {
  const report = emptyReport('solana', mint)
  const r = await getJson<RugReport>(`https://api.rugcheck.xyz/v1/tokens/${mint}/report`)
  if (!r?.mint) return report

  const liq = (m: NonNullable<RugReport['markets']>[number]) => (m.lp?.quoteUSD ?? 0) + (m.lp?.baseUSD ?? 0)
  const mainMarket = [...(r.markets ?? [])].filter((m) => m.lp).sort((a, b) => liq(b) - liq(a))[0]

  const known = r.knownAccounts ?? {}
  const isPoolOrLocker = (a: string) => !!known[a] && known[a].type !== 'CREATOR'
  const holders = r.topHolders ?? []
  const realHolders = holders.filter((h) => !isPoolOrLocker(h.owner) && !isPoolOrLocker(h.address))

  return {
    ...report,
    available: true,
    lpLockedPct: mainMarket?.lp?.lpLockedPct ?? null,
    mintRevoked: r.mintAuthority == null,
    freezeRevoked: r.freezeAuthority == null,
    insiderPct: holders.length ? holders.filter((h) => h.insider).reduce((s, h) => s + h.pct, 0) : null,
    insiderNetworks: r.insiderNetworks?.length ?? r.graphInsidersDetected ?? 0,
    dangerFlags: (r.risks ?? []).filter((x) => x.level === 'danger').map((x) => x.name),
    top10Pct: realHolders.length ? realHolders.slice(0, 10).reduce((s, h) => s + h.pct, 0) : null,
    totalHolders: r.totalHolders ?? null,
  }
}

interface GoPlusToken {
  is_mintable?: string
  owner_address?: string
  is_honeypot?: string
  sell_tax?: string
  lp_holders?: { address: string; percent: string; is_locked: number }[]
  holders?: { address: string; percent: string; is_locked: number; is_contract: number }[]
  holder_count?: string
}

const flag = (v: string | undefined) => (v === '1' ? true : v === '0' ? false : null)

async function baseSecurity(address: string): Promise<SecurityReport> {
  const report = emptyReport('base', address)
  const res = await getJson<{ code: number; result?: Record<string, GoPlusToken> }>(
    `https://api.gopluslabs.io/api/v1/token_security/8453?contract_addresses=${address}`,
  )
  const t = res?.result?.[address.toLowerCase()] ?? Object.values(res?.result ?? {})[0]
  if (res?.code !== 1 || !t) return report

  const lpHolders = t.lp_holders ?? []
  const lockedPct = lpHolders
    .filter((h) => h.is_locked === 1 || BURN_ADDRESSES.has(h.address.toLowerCase()))
    .reduce((s, h) => s + Number(h.percent), 0)

  const owner = t.owner_address?.toLowerCase()
  const realHolders = (t.holders ?? []).filter(
    (h) => h.is_contract !== 1 && h.is_locked !== 1 && !BURN_ADDRESSES.has(h.address.toLowerCase()),
  )
  const mintable = flag(t.is_mintable)
  const sellTax = t.sell_tax ? Number(t.sell_tax) * 100 : null

  return {
    ...report,
    available: true,
    lpLockedPct: lpHolders.length ? Math.min(100, lockedPct * 100) : null,
    mintRevoked: mintable == null ? null : !mintable,
    ownerRenounced: owner === undefined ? null : owner === '' || BURN_ADDRESSES.has(owner),
    honeypot: flag(t.is_honeypot),
    sellTaxPct: Number.isFinite(sellTax) ? sellTax : null,
    top10Pct: realHolders.length
      ? realHolders.slice(0, 10).reduce((s, h) => s + Number(h.percent), 0) * 100
      : null,
    totalHolders: t.holder_count ? Number(t.holder_count) : null,
  }
}

export function getSecurityReport(chain: Chain, address: string) {
  return chain === 'solana' ? solanaSecurity(address) : baseSecurity(address)
}
