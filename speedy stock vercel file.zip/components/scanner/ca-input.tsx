'use client'

import { useState } from 'react'
import { Loader, ScanSearch } from 'lucide-react'
import type { Chain } from '@/lib/scanner'
import { cn } from '@/lib/utils'

type ChainChoice = 'auto' | Chain

interface Props {
  onSubmit: (address: string, chain: Chain | null) => void
  isLoading: boolean
  error: string | null
}

export function CaInput({ onSubmit, isLoading, error }: Props) {
  const [value, setValue] = useState('')
  const [chain, setChain] = useState<ChainChoice>('auto')

  function submit(e: React.FormEvent) {
    e.preventDefault()
    const address = value.trim()
    if (address) onSubmit(address, chain === 'auto' ? null : chain)
  }

  return (
    <section aria-labelledby="ca-heading" className="rounded-xl border border-slate-800 bg-slate-900/50 p-4">
      <div className="mb-3 flex items-center justify-between">
        <h2 id="ca-heading" className="text-sm font-medium text-slate-200">
          Rapid CA Validation
        </h2>
        <span className="text-xs text-slate-500">Paste a mint or 0x address</span>
      </div>
      <form onSubmit={submit} className="flex flex-col gap-2 md:flex-row">
        <div
          role="radiogroup"
          aria-label="Chain"
          className="flex shrink-0 rounded-lg border border-slate-800 bg-slate-950 p-1"
        >
          {(['auto', 'solana', 'base'] as const).map((c) => (
            <button
              key={c}
              type="button"
              role="radio"
              aria-checked={chain === c}
              onClick={() => setChain(c)}
              className={cn(
                'rounded-md px-3 py-1.5 text-xs font-medium capitalize transition-colors',
                chain === c ? 'bg-slate-800 text-slate-50' : 'text-slate-500 hover:text-slate-300',
              )}
            >
              {c}
            </button>
          ))}
        </div>
        <label htmlFor="ca" className="sr-only">
          Contract address
        </label>
        <input
          id="ca"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onPaste={(e) => {
            const pasted = e.clipboardData.getData('text').trim()
            if (pasted) {
              e.preventDefault()
              setValue(pasted)
              onSubmit(pasted, chain === 'auto' ? null : chain)
            }
          }}
          placeholder="e.g. 7xKX…pump or 0x4ed4…"
          autoComplete="off"
          spellCheck={false}
          className="min-w-0 flex-1 rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 font-mono text-sm text-slate-100 placeholder:text-slate-600 focus:border-emerald-500/60 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
        />
        <button
          type="submit"
          disabled={isLoading || !value.trim()}
          className="inline-flex items-center justify-center gap-2 rounded-lg bg-emerald-500 px-4 py-2 text-sm font-semibold text-slate-950 transition-colors hover:bg-emerald-400 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {isLoading ? (
            <Loader aria-hidden className="size-4 animate-spin" />
          ) : (
            <ScanSearch aria-hidden className="size-4" />
          )}
          Run Audit
        </button>
      </form>
      {error && (
        <p role="alert" className="mt-2 text-xs text-red-400">
          {error}
        </p>
      )}
    </section>
  )
}
