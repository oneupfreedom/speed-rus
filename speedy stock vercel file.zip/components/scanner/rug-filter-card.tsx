import { ShieldAlert, ShieldCheck } from 'lucide-react'
import { RUG_PASS_BELOW, type RugResult } from '@/lib/scanner'
import { cn } from '@/lib/utils'

const MAX_SCORE = 135

export function RugFilterCard({ rug }: { rug: RugResult }) {
  const Icon = rug.passed ? ShieldCheck : ShieldAlert
  const pct = Math.min(100, (rug.riskScore / MAX_SCORE) * 100)
  const unverifiedHolders = rug.rules.some((r) => r.id === 'holders' && r.unverified)

  return (
    <section
      aria-labelledby="rug-heading"
      className={cn(
        'rounded-lg border p-3',
        rug.passed ? 'border-slate-800 bg-slate-950/60' : 'border-red-500/40 bg-red-500/5',
      )}
    >
      <div className="flex items-center justify-between gap-3">
        <h3 id="rug-heading" className="flex items-center gap-2 text-sm font-medium text-slate-200">
          <Icon aria-hidden className={cn('size-4', rug.passed ? 'text-emerald-400' : 'text-red-500')} />
          Rug Pull Filter
        </h3>
        <span
          className={cn(
            'rounded px-2 py-0.5 font-mono text-xs font-semibold',
            rug.passed ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/15 text-red-500',
          )}
        >
          {rug.passed ? 'PASSED' : 'DISCARD'} · {rug.riskScore} pts
        </span>
      </div>

      <div className="mt-3">
        <div
          className="relative h-1.5 overflow-hidden rounded-full bg-slate-800"
          role="meter"
          aria-label="Rug risk score"
          aria-valuemin={0}
          aria-valuemax={MAX_SCORE}
          aria-valuenow={rug.riskScore}
        >
          <div
            className={cn('h-full rounded-full', rug.passed ? 'bg-emerald-400' : 'bg-red-500')}
            style={{ width: `${pct}%` }}
          />
          <div
            aria-hidden
            className="absolute inset-y-0 w-px bg-slate-300"
            style={{ left: `${(RUG_PASS_BELOW / MAX_SCORE) * 100}%` }}
          />
        </div>
        <p className="mt-1 text-[10px] text-slate-500">Discard at {RUG_PASS_BELOW}+ points</p>
      </div>

      <ul className="mt-3 flex flex-col gap-1.5">
        {rug.rules.map((r) => (
          <li key={r.id} className="flex items-center justify-between gap-3 text-xs">
            <span className="min-w-0 text-slate-400">
              {r.label} <span className="text-slate-600">{r.threshold}</span>
            </span>
            <span className="flex shrink-0 items-center gap-2 font-mono tabular-nums">
              <span className={r.triggered ? 'text-red-500' : r.unverified ? 'text-amber-400' : 'text-slate-200'}>
                {r.value}
              </span>
              <span
                className={cn(
                  'w-10 text-right',
                  r.triggered ? 'font-semibold text-red-500' : 'text-slate-600',
                )}
              >
                {r.triggered ? `+${r.points}` : '0'}
              </span>
            </span>
          </li>
        ))}
      </ul>

      {rug.warnings.length > 0 && (
        <ul className="mt-3 flex flex-col gap-1 border-t border-red-500/20 pt-2">
          {rug.warnings.map((w) => (
            <li key={w} className="text-[11px] leading-relaxed text-red-400">
              {w}
            </li>
          ))}
        </ul>
      )}
      {unverifiedHolders && (
        <p className="mt-2 text-[11px] text-amber-400/80">
          Holder share unverified. Enter it in Gate 4 to include the +50 whale check.
        </p>
      )}
    </section>
  )
}
