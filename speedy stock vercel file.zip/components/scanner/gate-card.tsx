'use client'

import { Activity, Droplets, Gauge, Shield, Users } from 'lucide-react'
import type { GateResult } from '@/lib/scanner'
import { cn } from '@/lib/utils'
import { StatusIcon, statusBg, statusBorder, statusLabel, statusText } from './status'

const gateIcons = [Gauge, Activity, Droplets, Shield, Users]

interface Props {
  gates: GateResult[]
  top10Override: string
  onTop10OverrideChange: (v: string) => void
  holderDataAvailable: boolean
}

export function GateCard({ gates, top10Override, onTop10OverrideChange, holderDataAvailable }: Props) {
  const passed = gates.filter((g) => g.status === 'pass').length

  return (
    <section aria-labelledby="gates-heading" className="rounded-xl border border-slate-800 bg-slate-900/50">
      <div className="flex items-center justify-between border-b border-slate-800 px-4 py-3">
        <h2 id="gates-heading" className="text-sm font-medium text-slate-200">
          5-Gate Yardstick
        </h2>
        <div className="flex items-center gap-2">
          <div className="flex gap-1" aria-hidden>
            {gates.map((g) => (
              <span
                key={g.id}
                className={cn(
                  'h-1.5 w-5 rounded-full',
                  g.status === 'pass' ? 'bg-emerald-400' : g.status === 'warn' ? 'bg-amber-400' : 'bg-red-500',
                )}
              />
            ))}
          </div>
          <span className="font-mono text-xs text-slate-400">{passed}/5 pass</span>
        </div>
      </div>

      <ol className="divide-y divide-slate-800">
        {gates.map((gate, i) => {
          const Icon = gateIcons[i]
          return (
            <li key={gate.id} className="px-4 py-3">
              <div className="flex items-start gap-3">
                <div
                  className={cn(
                    'flex size-9 shrink-0 items-center justify-center rounded-lg border',
                    statusBorder[gate.status],
                    statusBg[gate.status],
                  )}
                >
                  <Icon aria-hidden className={cn('size-4', statusText[gate.status])} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-medium text-slate-100">
                      <span className="font-mono text-slate-500">G{gate.id}</span> {gate.name}
                    </p>
                    <span
                      className={cn(
                        'inline-flex items-center gap-1 rounded border px-1.5 py-0.5 font-mono text-[10px] font-semibold tracking-wider',
                        statusBorder[gate.status],
                        statusBg[gate.status],
                        statusText[gate.status],
                      )}
                    >
                      {statusLabel[gate.status]}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">{gate.criteria}</p>
                  <ul className="mt-2 grid gap-1">
                    {gate.checks.map((c) => (
                      <li key={c.label} className="flex items-center justify-between gap-2 text-xs">
                        <span className="flex items-center gap-1.5 text-slate-400">
                          <StatusIcon status={c.status} className="size-3.5" />
                          {c.label}
                        </span>
                        <span className={cn('font-mono tabular-nums', statusText[c.status])}>{c.value}</span>
                      </li>
                    ))}
                  </ul>
                  {gate.id === 4 && (
                    <div className="mt-2 flex items-center gap-2">
                      <label htmlFor="top10" className="text-xs text-slate-500">
                        {holderDataAvailable ? 'Override Top 10 %' : 'Enter Top 10 % (from explorer)'}
                      </label>
                      <input
                        id="top10"
                        inputMode="decimal"
                        value={top10Override}
                        onChange={(e) => onTop10OverrideChange(e.target.value.replace(/[^\d.]/g, ''))}
                        placeholder="—"
                        className="w-20 rounded-md border border-slate-800 bg-slate-950 px-2 py-1 font-mono text-xs text-slate-100 placeholder:text-slate-600 focus:border-emerald-500/60 focus:outline-none"
                      />
                    </div>
                  )}
                </div>
              </div>
            </li>
          )
        })}
      </ol>
    </section>
  )
}
