import { CircleCheck, CircleX, TriangleAlert } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { GateStatus, Verdict } from '@/lib/scanner'

export const statusText: Record<GateStatus, string> = {
  pass: 'text-emerald-400',
  warn: 'text-amber-400',
  fail: 'text-red-500',
}

export const statusBorder: Record<GateStatus, string> = {
  pass: 'border-emerald-500/40',
  warn: 'border-amber-400/40',
  fail: 'border-red-500/40',
}

export const statusBg: Record<GateStatus, string> = {
  pass: 'bg-emerald-500/10',
  warn: 'bg-amber-400/10',
  fail: 'bg-red-500/10',
}

export const statusLabel: Record<GateStatus, string> = {
  pass: 'PASS',
  warn: 'WARN',
  fail: 'FAIL',
}

export function StatusIcon({ status, className }: { status: GateStatus; className?: string }) {
  const Icon = status === 'pass' ? CircleCheck : status === 'warn' ? TriangleAlert : CircleX
  return <Icon aria-hidden className={cn('size-4 shrink-0', statusText[status], className)} />
}

const verdictToStatus: Record<Verdict, GateStatus> = { green: 'pass', yellow: 'warn', red: 'fail' }
const verdictLabel: Record<Verdict, string> = { green: 'Green', yellow: 'Yellow', red: 'Red' }

export function VerdictTag({ verdict }: { verdict: Verdict }) {
  const s = verdictToStatus[verdict]
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-md border px-2 py-0.5 font-mono text-xs font-medium',
        statusBorder[s],
        statusBg[s],
        statusText[s],
      )}
    >
      <span aria-hidden className={cn('size-1.5 rounded-full bg-current')} />
      {verdictLabel[verdict]}
    </span>
  )
}

export function verdictStatus(v: Verdict) {
  return verdictToStatus[v]
}
