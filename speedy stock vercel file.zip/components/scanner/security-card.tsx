import { ExternalLink, LineChart, ShieldCheck } from 'lucide-react'
import type { GateResult, SecurityReport, TokenMetrics } from '@/lib/scanner'
import { cn } from '@/lib/utils'
import { StatusIcon, statusBg, statusBorder, statusLabel, statusText } from './status'

interface Props {
  gate: GateResult
  report: SecurityReport | undefined
  token: TokenMetrics
  isLoading: boolean
}

export function SecurityCard({ gate, report, token, isLoading }: Props) {
  return (
    <div className="flex flex-col gap-4">
      <section aria-labelledby="security-heading" className="rounded-xl border border-slate-800 bg-slate-900/50">
        <div className="flex items-center justify-between gap-2 border-b border-slate-800 px-4 py-3">
          <div className="flex items-center gap-2">
            <ShieldCheck aria-hidden className="size-4 text-cyan-400" />
            <h2 id="security-heading" className="text-sm font-medium text-slate-200">
              <span className="font-mono text-slate-500">G6</span> Security &amp; Integrity
            </h2>
          </div>
          <span
            className={cn(
              'rounded border px-1.5 py-0.5 font-mono text-[10px] font-semibold tracking-wider',
              statusBorder[gate.status],
              statusBg[gate.status],
              statusText[gate.status],
            )}
          >
            {isLoading ? 'SCANNING' : statusLabel[gate.status]}
          </span>
        </div>

        <div className="flex flex-col gap-2 p-4">
          <p className="text-xs text-slate-500">{gate.criteria}</p>
          {isLoading ? (
            <ul className="grid gap-2" aria-busy="true" aria-label="Loading security checks">
              {Array.from({ length: 4 }).map((_, i) => (
                <li key={i} className="h-10 animate-pulse rounded-lg border border-slate-800/60 bg-slate-950/60" />
              ))}
            </ul>
          ) : (
            <ul className="grid gap-2">
              {gate.checks.map((c) => (
                <li
                  key={c.label}
                  className="flex items-center justify-between gap-3 rounded-lg border border-slate-800/60 bg-slate-950/60 px-3 py-2.5 text-xs"
                >
                  <span className="flex min-w-0 items-center gap-2 text-slate-300">
                    <StatusIcon status={c.status} className="size-3.5" />
                    <span className="truncate">{c.label}</span>
                  </span>
                  <span
                    className={cn(
                      'shrink-0 rounded px-2 py-0.5 font-mono text-[11px] font-semibold uppercase',
                      statusBg[c.status],
                      statusText[c.status],
                    )}
                  >
                    {c.value}
                  </span>
                </li>
              ))}
            </ul>
          )}
          {report && (
            <p className="flex flex-wrap items-center justify-between gap-2 pt-1 text-[11px] text-slate-500">
              <span>
                Source: {report.source}
                {report.totalHolders ? ` · ${report.totalHolders.toLocaleString('en-US')} holders` : ''}
              </span>
              <a
                href={report.reportUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-cyan-400 hover:text-cyan-300"
              >
                Full report
                <ExternalLink aria-hidden className="size-3" />
                <span className="sr-only">(opens in new tab)</span>
              </a>
            </p>
          )}
        </div>
      </section>

      <aside className="flex items-start gap-3 rounded-xl border border-amber-400/30 bg-amber-400/5 p-4 text-xs">
        <LineChart aria-hidden className="mt-0.5 size-4 shrink-0 text-amber-400" />
        <div className="flex flex-col gap-1.5">
          <p className="font-semibold uppercase tracking-wide text-amber-400">Manual pre-flight check</p>
          <p className="leading-relaxed text-slate-300">
            Even with clean security gates, check the live chart before entering so you don&apos;t chase a sudden sell
            candle.
          </p>
          <a
            href={token.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex w-fit items-center gap-1 font-medium text-amber-400 hover:text-amber-300"
          >
            Open ${token.symbol} on DexScreener
            <ExternalLink aria-hidden className="size-3" />
            <span className="sr-only">(opens in new tab)</span>
          </a>
        </div>
      </aside>
    </div>
  )
}
