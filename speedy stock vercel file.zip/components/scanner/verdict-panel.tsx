'use client'

import { useState } from 'react'
import { CircleCheck, CircleX, Copy, ExternalLink, Rocket, Target, TriangleAlert, Turtle, Zap } from 'lucide-react'
import {
  formatAge,
  formatPrice,
  formatUsd,
  shortAddress,
  volMcRatio,
  type RugResult,
  type Speed,
  type TokenMetrics,
  type Verdict,
} from '@/lib/scanner'
import { cn } from '@/lib/utils'
import { RugFilterCard } from './rug-filter-card'

const verdictConfig: Record<Verdict, { label: string; sub: string; icon: typeof CircleCheck; cls: string }> = {
  green: {
    label: 'GREEN LIGHT (PASS)',
    sub: 'All 6 gates cleared (momentum + security). Entry window is open',
    icon: CircleCheck,
    cls: 'border-emerald-500/50 bg-emerald-500/10 text-emerald-400 shadow-[0_0_40px_-12px] shadow-emerald-500/50',
  },
  yellow: {
    label: 'YELLOW (CAUTION)',
    sub: 'No hard fails, but one or more gates need confirmation',
    icon: TriangleAlert,
    cls: 'border-amber-400/50 bg-amber-400/10 text-amber-400',
  },
  red: {
    label: 'RED (NO ENTRY)',
    sub: 'At least one gate failed — skip or wait for setup',
    icon: CircleX,
    cls: 'border-red-500/50 bg-red-500/10 text-red-500',
  },
}

interface Props {
  token: TokenMetrics
  verdict: Verdict
  speed: Speed
  rug: RugResult
}

export function VerdictPanel({ token, verdict, speed, rug }: Props) {
  const v = verdictConfig[verdict]
  const VIcon = v.icon
  const [entryInput, setEntryInput] = useState('')
  const [sizeInput, setSizeInput] = useState('500')
  const [copied, setCopied] = useState(false)

  const entryMc = Number(entryInput) > 0 ? Number(entryInput) : token.marketCap
  const size = Number(sizeInput) > 0 ? Number(sizeInput) : 0
  const priceAt = (mc: number) => (token.marketCap > 0 ? (token.priceUsd * mc) / token.marketCap : 0)
  const deRiskMc = entryMc * 2
  const moonMc = entryMc * 10

  async function copy() {
    await navigator.clipboard.writeText(token.address)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  return (
    <section aria-labelledby="verdict-heading" className="flex flex-col gap-4 rounded-xl border border-slate-800 bg-slate-900/50 p-4">
      <div className="flex items-center gap-3">
        {token.imageUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={token.imageUrl} alt="" className="size-10 rounded-lg bg-slate-800 object-cover" />
        ) : (
          <div className="flex size-10 items-center justify-center rounded-lg bg-slate-800 font-mono text-xs text-slate-400">
            {token.symbol.slice(0, 3)}
          </div>
        )}
        <div className="min-w-0 flex-1">
          <h2 id="verdict-heading" className="truncate text-base font-semibold text-slate-50">
            {token.name} <span className="font-mono text-sm text-slate-500">${token.symbol}</span>
          </h2>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500">
            <span className="capitalize">{token.chain}</span>
            <span>{formatAge(token.pairCreatedAt)} old</span>
            <button type="button" onClick={copy} className="inline-flex items-center gap-1 font-mono hover:text-slate-300">
              <Copy aria-hidden className="size-3" />
              {copied ? 'Copied' : shortAddress(token.address)}
            </button>
            <a href={token.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 hover:text-slate-300">
              <ExternalLink aria-hidden className="size-3" />
              Chart
            </a>
          </div>
        </div>
        <div className="text-right">
          <p className="font-mono text-sm text-slate-100">{formatPrice(token.priceUsd)}</p>
          <p className={cn('font-mono text-xs', token.priceChangeH1 >= 0 ? 'text-emerald-400' : 'text-red-500')}>
            {token.priceChangeH1 >= 0 ? '+' : ''}
            {token.priceChangeH1.toFixed(1)}% 1h
          </p>
        </div>
      </div>

      <div className={cn('rounded-xl border p-4', v.cls)} role="status" aria-live="polite">
        <div className="flex items-center gap-3">
          <VIcon aria-hidden className="size-8 shrink-0" />
          <div>
            <p className="text-xl font-bold tracking-tight md:text-2xl">{v.label}</p>
            <p className="text-xs opacity-80">
              {verdict === 'red' && !rug.passed ? `Rug filter tripped (${rug.riskScore} pts). Token discarded` : v.sub}
            </p>
          </div>
        </div>
      </div>

      <RugFilterCard rug={rug} />

      <div
        className={cn(
          'flex items-center justify-between rounded-lg border px-4 py-3',
          speed === 'high' ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-sky-400/30 bg-sky-400/5',
        )}
      >
        <div className="flex items-center gap-2">
          {speed === 'high' ? (
            <Zap aria-hidden className="size-5 text-emerald-400" />
          ) : (
            <Turtle aria-hidden className="size-5 text-sky-400" />
          )}
          <span className={cn('text-sm font-semibold', speed === 'high' ? 'text-emerald-400' : 'text-sky-400')}>
            {speed === 'high' ? 'HIGH-SPEED MOMENTUM' : 'MODERATE ACCUMULATION'}
          </span>
        </div>
        <span className="font-mono text-xs text-slate-400">{volMcRatio(token).toFixed(2)}x Vol/MC</span>
      </div>

      <div>
        <h3 className="mb-2 flex items-center gap-2 text-sm font-medium text-slate-200">
          <Target aria-hidden className="size-4 text-slate-500" />
          Price &amp; Target Calculator
        </h3>
        <div className="mb-3 grid grid-cols-2 gap-2">
          <label className="flex flex-col gap-1 text-xs text-slate-500">
            Entry MC (USD)
            <input
              inputMode="numeric"
              value={entryInput}
              onChange={(e) => setEntryInput(e.target.value.replace(/[^\d.]/g, ''))}
              placeholder={Math.round(token.marketCap).toString()}
              className="rounded-md border border-slate-800 bg-slate-950 px-2 py-1.5 font-mono text-sm text-slate-100 placeholder:text-slate-600 focus:border-emerald-500/60 focus:outline-none"
            />
          </label>
          <label className="flex flex-col gap-1 text-xs text-slate-500">
            Position size (USD)
            <input
              inputMode="numeric"
              value={sizeInput}
              onChange={(e) => setSizeInput(e.target.value.replace(/[^\d.]/g, ''))}
              className="rounded-md border border-slate-800 bg-slate-950 px-2 py-1.5 font-mono text-sm text-slate-100 focus:border-emerald-500/60 focus:outline-none"
            />
          </label>
        </div>

        <div className="grid gap-2">
          <TargetRow
            label="Entry Market Cap"
            hint="Current position basis"
            mc={entryMc}
            price={priceAt(entryMc)}
            detail={`Size ${formatUsd(size)}`}
            tone="slate"
          />
          <TargetRow
            label="1x De-Risk Level"
            hint="2x MC · pull 50% capital"
            mc={deRiskMc}
            price={priceAt(deRiskMc)}
            detail={`Pull ${formatUsd(size)} · ride ${formatUsd(size)}`}
            tone="amber"
          />
          <TargetRow
            label="10x Moonshot Target"
            hint="Free position floor"
            mc={moonMc}
            price={priceAt(moonMc)}
            detail={`Bag worth ${formatUsd(size * 5)}`}
            tone="emerald"
            icon
          />
        </div>
      </div>
    </section>
  )
}

const toneCls = {
  slate: 'border-slate-800 text-slate-100',
  amber: 'border-amber-400/30 text-amber-400',
  emerald: 'border-emerald-500/30 text-emerald-400',
}

function TargetRow({
  label,
  hint,
  mc,
  price,
  detail,
  tone,
  icon,
}: {
  label: string
  hint: string
  mc: number
  price: number
  detail: string
  tone: keyof typeof toneCls
  icon?: boolean
}) {
  return (
    <div className={cn('flex items-center justify-between gap-3 rounded-lg border bg-slate-950/60 px-3 py-2.5', toneCls[tone])}>
      <div className="min-w-0">
        <p className="flex items-center gap-1.5 text-sm font-medium">
          {icon && <Rocket aria-hidden className="size-3.5" />}
          {label}
        </p>
        <p className="text-xs text-slate-500">{hint}</p>
      </div>
      <div className="text-right">
        <p className="font-mono text-base font-semibold tabular-nums">{formatUsd(mc)}</p>
        <p className="font-mono text-[11px] text-slate-500">
          {formatPrice(price)} · {detail}
        </p>
      </div>
    </div>
  )
}
