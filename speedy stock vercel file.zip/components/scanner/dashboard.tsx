'use client'

import { useMemo, useState } from 'react'
import useSWR from 'swr'
import { Radar } from 'lucide-react'
import {
  evaluateGates,
  evaluateRugRisk,
  evaluateSecurity,
  getSpeed,
  getVerdict,
  type Chain,
  type SecurityReport,
  type TokenMetrics,
} from '@/lib/scanner'
import { SecurityCard } from './security-card'
import { ScannerHeader } from './scanner-header'
import { CaInput } from './ca-input'
import { GateCard } from './gate-card'
import { VerdictPanel } from './verdict-panel'
import { ScannerTable, type ScoredToken } from './scanner-table'

async function fetcher<T>(url: string): Promise<T> {
  const res = await fetch(url)
  const json = await res.json()
  if (!res.ok) throw new Error(json.error ?? 'Request failed')
  return json as T
}

type Selection = { source: 'feed'; key: string } | { source: 'audit'; address: string; chain: Chain | null }

export function Dashboard() {
  const scan = useSWR<{ tokens: TokenMetrics[]; scannedAt: number }>('/api/scan', fetcher, {
    refreshInterval: 20_000,
    keepPreviousData: true,
  })
  const [selection, setSelection] = useState<Selection | null>(null)
  const [overrides, setOverrides] = useState<Record<string, string>>({})

  const auditKey =
    selection?.source === 'audit'
      ? `/api/audit?address=${encodeURIComponent(selection.address)}${selection.chain ? `&chain=${selection.chain}` : ''}`
      : null
  const audit = useSWR<{ token: TokenMetrics }>(auditKey, fetcher, { refreshInterval: 15_000, shouldRetryOnError: false })

  const scored: ScoredToken[] = useMemo(
    () =>
      (scan.data?.tokens ?? []).map((t) => {
        const rug = evaluateRugRisk(t, t.top10Pct)
        return { ...t, rug, verdict: getVerdict(evaluateGates(t), rug) }
      }),
    [scan.data],
  )

  const active: TokenMetrics | null = useMemo(() => {
    if (selection?.source === 'audit') return audit.data?.token ?? null
    const key = selection?.source === 'feed' ? selection.key : null
    const rank = { green: 0, yellow: 1, red: 2 }
    const best = [...scored].sort((a, b) => rank[a.verdict] - rank[b.verdict])[0]
    return (key && scored.find((t) => `${t.chain}:${t.address}` === key)) || best || null
  }, [selection, audit.data, scored])

  const activeKey = active ? `${active.chain}:${active.address}` : null
  const security = useSWR<{ report: SecurityReport }>(
    active ? `/api/security?chain=${active.chain}&address=${encodeURIComponent(active.address)}` : null,
    fetcher,
    { refreshInterval: 60_000, shouldRetryOnError: false },
  )
  const report = security.data?.report
  const securityPending = security.isLoading || (!report && !security.error)

  const overrideRaw = activeKey ? (overrides[activeKey] ?? '') : ''
  const override = overrideRaw !== '' && Number.isFinite(Number(overrideRaw)) ? Number(overrideRaw) : null
  const top10 = override ?? report?.top10Pct ?? active?.top10Pct ?? null
  const gates = active ? evaluateGates(active, top10) : null
  const rug = active ? evaluateRugRisk(active, top10) : null
  const securityGate = active
    ? evaluateSecurity(securityPending ? undefined : (report ?? null), active.chain)
    : null

  return (
    <div className="min-h-dvh bg-slate-950 text-slate-100">
      <ScannerHeader
        scannedAt={scan.data?.scannedAt ?? null}
        isValidating={scan.isValidating}
        isError={!!scan.error}
        tokenCount={scored.length}
        onRefresh={() => scan.mutate()}
      />

      <main className="mx-auto flex max-w-[1440px] flex-col gap-4 px-4 py-4 md:px-6 md:py-6">
        <CaInput
          onSubmit={(address, chain) => setSelection({ source: 'audit', address, chain })}
          isLoading={audit.isLoading}
          error={selection?.source === 'audit' && audit.error ? (audit.error as Error).message : null}
        />

        <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
          {active && gates && securityGate && rug ? (
            <>
              <div className="flex min-w-0 flex-col gap-4">
                <GateCard
                  gates={gates}
                  top10Override={overrideRaw}
                  onTop10OverrideChange={(v) => activeKey && setOverrides((o) => ({ ...o, [activeKey]: v }))}
                  holderDataAvailable={active.top10Pct != null || report?.top10Pct != null}
                />
                <SecurityCard gate={securityGate} report={report} token={active} isLoading={securityPending} />
              </div>
              <VerdictPanel
                key={activeKey}
                token={active}
                verdict={getVerdict([...gates, securityGate], rug)}
                speed={getSpeed(active)}
                rug={rug}
              />
            </>
          ) : (
            <EmptyAudit loading={scan.isLoading || audit.isLoading} />
          )}
        </div>

        <ScannerTable
          tokens={scored}
          isLoading={scan.isLoading}
          selectedKey={activeKey}
          onSelect={(t) => setSelection({ source: 'feed', key: `${t.chain}:${t.address}` })}
          now={scan.data?.scannedAt ?? 0}
        />

        <p className="text-pretty text-center text-[11px] leading-relaxed text-slate-600">
          Market data via DexScreener. Buyer counts and buy-side flow use 1h buy transactions as a proxy. Gate 6 security
          and Top 10 holder share (pool and locker accounts excluded) come from RugCheck on Solana and GoPlus on Base, and
          apply to the selected token. Feed verdicts use the 5 momentum gates plus the rug filter. The rug filter&apos;s sell
          pressure check uses 5m transaction counts, since DexScreener has no 1m or unique-wallet data. Not financial advice.
        </p>
      </main>
    </div>
  )
}

function EmptyAudit({ loading }: { loading: boolean }) {
  return (
    <div className="col-span-full flex min-h-64 flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-slate-800 bg-slate-900/30 p-8 text-center">
      <Radar aria-hidden className={loading ? 'size-8 animate-pulse text-emerald-400' : 'size-8 text-slate-600'} />
      <p className="text-sm text-slate-300">{loading ? 'Scanning fresh pairs…' : 'No token selected'}</p>
      <p className="text-xs text-slate-500">Paste a contract address or pick a row from the live feed.</p>
    </div>
  )
}
