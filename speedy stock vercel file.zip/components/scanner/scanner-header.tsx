import { Clock, Radar, RefreshCw } from 'lucide-react'
import { cn } from '@/lib/utils'

interface Props {
  scannedAt: number | null
  isValidating: boolean
  isError: boolean
  tokenCount: number
  onRefresh: () => void
}

export function ScannerHeader({ scannedAt, isValidating, isError, tokenCount, onRefresh }: Props) {
  return (
    <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur supports-[backdrop-filter]:bg-slate-950/60 sticky top-0 z-20">
      <div className="mx-auto flex max-w-[1440px] flex-col gap-3 px-4 py-4 md:flex-row md:items-center md:justify-between md:px-6">
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-lg border border-emerald-500/30 bg-emerald-500/10">
            <Radar aria-hidden className="size-5 text-emerald-400" />
          </div>
          <div>
            <h1 className="text-balance text-lg font-semibold tracking-tight text-slate-50 md:text-xl">
              Speedy Momentum Scanner <span className="text-slate-500">&amp;</span> 5-Gate Audit
            </h1>
            <p className="text-xs text-slate-500">Solana + Base memecoin momentum, scored in real time</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span
            className={cn(
              'inline-flex items-center gap-2 rounded-md border px-2.5 py-1 font-mono',
              isError
                ? 'border-red-500/40 bg-red-500/10 text-red-400'
                : 'border-emerald-500/40 bg-emerald-500/10 text-emerald-400',
            )}
          >
            <span className="relative flex size-2">
              {!isError && (
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-emerald-400 opacity-60" />
              )}
              <span className={cn('relative inline-flex size-2 rounded-full', isError ? 'bg-red-500' : 'bg-emerald-400')} />
            </span>
            {isError ? 'FEED ERROR' : 'LIVE'}
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-md border border-slate-800 bg-slate-900 px-2.5 py-1 text-slate-300">
            <span aria-hidden className="size-1.5 rounded-full bg-violet-400" />
            Solana
            <span className="text-slate-600">/</span>
            <span aria-hidden className="size-1.5 rounded-full bg-sky-400" />
            Base priority
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-md border border-slate-800 bg-slate-900 px-2.5 py-1 text-slate-300">
            <Clock aria-hidden className="size-3.5 text-slate-500" />
            {'Pair age ≤ 24h'}
          </span>
          <span className="hidden font-mono text-slate-500 sm:inline">
            {tokenCount} captured
            {scannedAt ? ` · ${new Date(scannedAt).toLocaleTimeString()}` : ''}
          </span>
          <button
            type="button"
            onClick={onRefresh}
            className="inline-flex items-center gap-1.5 rounded-md border border-slate-800 bg-slate-900 px-2.5 py-1 text-slate-300 transition-colors hover:border-slate-700 hover:text-slate-50"
          >
            <RefreshCw aria-hidden className={cn('size-3.5', isValidating && 'animate-spin')} />
            Rescan
          </button>
        </div>
      </div>
    </header>
  )
}
