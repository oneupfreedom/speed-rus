'use client'

import { useEffect, useRef, useState } from 'react'
import { Check, Copy, ExternalLink } from 'lucide-react'
import { cn } from '@/lib/utils'

async function writeClipboard(text: string) {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text)
      return true
    }
  } catch {
    // Clipboard API can be blocked inside iframes or by permissions; fall through to the legacy path.
  }
  const el = document.createElement('textarea')
  el.value = text
  el.setAttribute('readonly', '')
  el.style.position = 'fixed'
  el.style.top = '0'
  el.style.opacity = '0'
  document.body.appendChild(el)
  el.focus()
  el.select()
  el.setSelectionRange(0, text.length)
  let ok = false
  try {
    ok = document.execCommand('copy')
  } catch {
    ok = false
  }
  document.body.removeChild(el)
  return ok
}

export function shortAddress(address: string) {
  return address.length > 12 ? `${address.slice(0, 4)}…${address.slice(-4)}` : address
}

export function CopyCaButton({ address, symbol, className }: { address: string; symbol: string; className?: string }) {
  const [state, setState] = useState<'idle' | 'copied' | 'failed'>('idle')
  const timer = useRef<ReturnType<typeof setTimeout>>(undefined)

  useEffect(() => () => clearTimeout(timer.current), [])

  async function handleCopy(e: React.MouseEvent) {
    e.stopPropagation()
    const ok = await writeClipboard(address)
    setState(ok ? 'copied' : 'failed')
    clearTimeout(timer.current)
    timer.current = setTimeout(() => setState('idle'), 1600)
  }

  return (
    <button
      type="button"
      onClick={handleCopy}
      title={address}
      aria-label={`Copy contract address for ${symbol}`}
      className={cn(
        'inline-flex h-7 shrink-0 items-center gap-1.5 rounded-md border px-2 font-mono text-[11px] transition-colors',
        state === 'copied'
          ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-400'
          : state === 'failed'
            ? 'border-red-500/40 bg-red-500/10 text-red-400'
            : 'border-slate-700 bg-slate-950 text-slate-300 hover:border-slate-600 hover:text-slate-50',
        className,
      )}
    >
      {state === 'copied' ? <Check aria-hidden className="size-3" /> : <Copy aria-hidden className="size-3" />}
      <span>{state === 'copied' ? 'Copied' : state === 'failed' ? 'Failed' : 'Copy CA'}</span>
      <span className="sr-only" aria-live="polite">
        {state === 'copied' ? 'Contract address copied' : state === 'failed' ? 'Copy failed' : ''}
      </span>
    </button>
  )
}

export function DexLink({ url, symbol, className }: { url: string; symbol: string; className?: string }) {
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      onClick={(e) => e.stopPropagation()}
      title="Open pair on DexScreener"
      aria-label={`Open ${symbol} pair on DexScreener (new tab)`}
      className={cn(
        'inline-flex h-7 shrink-0 items-center gap-1 rounded-md border border-slate-700 bg-slate-950 px-2 text-[11px] font-medium text-slate-300 transition-colors hover:border-emerald-500/50 hover:text-emerald-400',
        className,
      )}
    >
      Dex
      <ExternalLink aria-hidden className="size-3" />
    </a>
  )
}
