'use client'

import { useMemo, useState } from 'react'
import { ArrowUpDown, Turtle, Zap } from 'lucide-react'
import {
  HIGH_SPEED_VOL_MC,
  buyRatio,
  formatAge,
  formatUsd,
  volMcRatio,
  type Chain,
  type TokenMetrics,
  type Verdict,
} from '@/lib/scanner'
import { cn } from '@/lib/utils'
import { VerdictTag } from './status'
import { CopyCaButton, DexLink, shortAddress } from './token-actions'

export interface ScoredToken extends TokenMetrics {
  verdict: Verdict
}

type SpeedFilter = 'all' | 'high' | 'moderate'
type ChainFilter = 'all' | Chain
type SortKey = 'age' | 'marketCap' | 'volumeH1' | 'volMc' | 'liquidityUsd' | 'buyRatio'

const verdictRank: Record<Verdict, number> = { green: 0, yellow: 1, red: 2 }

function sortValue(t: ScoredToken, key: SortKey) {
  switch (key) {
    case 'age':
      return -(t.pairCreatedAt ?? 0)
    case 'volMc':
      return volMcRatio(t)
    case 'buyRatio':
      return buyRatio(t.buysH1, t.sellsH1)
    default:
      return t[key]
  }
}

interface Props {
  tokens: ScoredToken[]
  isLoading: boolean
  selectedKey: string | null
  onSelect: (t: ScoredToken) => void
  now: number
}

export function ScannerTable({ tokens, isLoading, selectedKey, onSelect, now }: Props) {
  const [speed, setSpeed] = useState<SpeedFilter>('all')
  const [chain, setChain] = useState<ChainFilter>('all')
  const [sort, setSort] = useState<{ key: SortKey; desc: boolean }>({ key: 'volMc', desc: true })

  const rows = useMemo(() => {
    return tokens
      .filter((t) => chain === 'all' || t.chain === chain)
      .filter((t) => {
        if (speed === 'all') return true
        const high = volMcRatio(t) >= HIGH_SPEED_VOL_MC
        return speed === 'high' ? high : !high
      })
      .sort((a, b) => {
        const vr = verdictRank[a.verdict] - verdictRank[b.verdict]
        if (sort.key === 'volMc' && sort.desc && vr !== 0) return vr
        const d = sortValue(a, sort.key) - sortValue(b, sort.key)
        return sort.desc ? -d : d
      })
  }, [tokens, chain, speed, sort])

  const counts = useMemo(() => {
    const high = tokens.filter((t) => volMcRatio(t) >= HIGH_SPEED_VOL_MC).length
    return { all: tokens.length, high, moderate: tokens.length - high }
  }, [tokens])

  function toggleSort(key: SortKey) {
    setSort((s) => (s.key === key ? { key, desc: !s.desc } : { key, desc: true }))
  }

  const SortHeader = ({ k, children, className }: { k: SortKey; children: React.ReactNode; className?: string }) => (
    <th scope="col" className={cn('px-3 py-2 font-medium', className)} aria-sort={sort.key === k ? (sort.desc ? 'descending' : 'ascending') : 'none'}>
      <button
        type="button"
        onClick={() => toggleSort(k)}
        className={cn('inline-flex items-center gap-1 hover:text-slate-200', sort.key === k && 'text-slate-200')}
      >
        {children}
        <ArrowUpDown aria-hidden className="size-3" />
      </button>
    </th>
  )

  return (
    <section aria-labelledby="feed-heading" className="rounded-xl border border-slate-800 bg-slate-900/50">
      <div className="flex flex-col gap-3 border-b border-slate-800 px-4 py-3 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h2 id="feed-heading" className="text-sm font-medium text-slate-200">
            Live Scanner Feed
          </h2>
          <p className="text-xs text-slate-500">Fresh pairs captured from DexScreener · auto-refresh 20s · click a row to audit</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Segmented
            label="Momentum filter"
            value={speed}
            onChange={setSpeed}
            options={[
              { value: 'all', label: `All ${counts.all}` },
              { value: 'high', label: `High-Speed ${counts.high}`, icon: <Zap aria-hidden className="size-3" /> },
              { value: 'moderate', label: `Moderate ${counts.moderate}`, icon: <Turtle aria-hidden className="size-3" /> },
            ]}
          />
          <Segmented
            label="Chain filter"
            value={chain}
            onChange={setChain}
            options={[
              { value: 'all', label: 'All chains' },
              { value: 'solana', label: 'Solana' },
              { value: 'base', label: 'Base' },
            ]}
          />
        </div>
      </div>

      <ul className="divide-y divide-slate-800/60 md:hidden" aria-label="Scanner results">
        {isLoading &&
          Array.from({ length: 5 }).map((_, i) => (
            <li key={i} className="px-4 py-4">
              <div className="h-16 animate-pulse rounded bg-slate-800/60" />
            </li>
          ))}
        {!isLoading && rows.length === 0 && (
          <li className="px-4 py-10 text-center text-sm text-slate-500">
            No candidates match these filters right now. The feed rescans automatically.
          </li>
        )}
        {rows.map((t) => (
          <TokenCard
            key={`${t.chain}:${t.address}`}
            token={t}
            now={now}
            selected={`${t.chain}:${t.address}` === selectedKey}
            onSelect={onSelect}
          />
        ))}
      </ul>

      <div className="hidden overflow-x-auto md:block">
        <table className="w-full min-w-[1120px] text-left text-xs">
          <thead className="text-slate-500">
            <tr className="border-b border-slate-800">
              <th scope="col" className="px-3 py-2 pl-4 font-medium">Token</th>
              <SortHeader k="age">Age</SortHeader>
              <SortHeader k="marketCap">Market Cap</SortHeader>
              <SortHeader k="volumeH1">1h Vol</SortHeader>
              <SortHeader k="volMc">Vol/MC</SortHeader>
              <SortHeader k="liquidityUsd">Liquidity</SortHeader>
              <th scope="col" className="px-3 py-2 font-medium">Top 10 %</th>
              <SortHeader k="buyRatio">Buy/Sell</SortHeader>
              <th scope="col" className="px-3 py-2 pr-4 font-medium">Verdict</th>
            </tr>
          </thead>
          <tbody className="font-mono tabular-nums">
            {isLoading &&
              Array.from({ length: 8 }).map((_, i) => (
                <tr key={i} className="border-b border-slate-800/60">
                  <td colSpan={9} className="px-4 py-3">
                    <div className="h-4 animate-pulse rounded bg-slate-800/60" />
                  </td>
                </tr>
              ))}
            {!isLoading && rows.length === 0 && (
              <tr>
                <td colSpan={9} className="px-4 py-10 text-center font-sans text-sm text-slate-500">
                  No candidates match these filters right now. The feed rescans automatically.
                </td>
              </tr>
            )}
            {rows.map((t) => {
              const key = `${t.chain}:${t.address}`
              const vm = volMcRatio(t)
              const br = buyRatio(t.buysH1, t.sellsH1)
              const selected = key === selectedKey
              return (
                <tr
                  key={key}
                  onClick={() => onSelect(t)}
                  className={cn(
                    'cursor-pointer border-b border-slate-800/60 transition-colors hover:bg-slate-800/40',
                    selected && 'bg-emerald-500/5',
                  )}
                >
                  <td className="px-3 py-2.5 pl-4">
                    <div className="flex items-center gap-2">
                      <TokenIdentity token={t} selected={selected} onSelect={onSelect} />
                      <DexLink url={t.url} symbol={t.symbol} />
                      <CopyCaButton address={t.address} symbol={t.symbol} />
                    </div>
                  </td>
                  <td className="px-3 py-2.5 text-slate-300">{formatAge(t.pairCreatedAt, now)}</td>
                  <td className="px-3 py-2.5 text-slate-100">{formatUsd(t.marketCap)}</td>
                  <td className="px-3 py-2.5 text-slate-300">{formatUsd(t.volumeH1)}</td>
                  <td className={cn('px-3 py-2.5', vm >= HIGH_SPEED_VOL_MC ? 'text-emerald-400' : vm >= 1 ? 'text-slate-100' : 'text-slate-500')}>
                    {vm.toFixed(2)}x
                  </td>
                  <td className="px-3 py-2.5 text-slate-300">{formatUsd(t.liquidityUsd)}</td>
                  <td className="px-3 py-2.5 text-slate-500">
                    {t.top10Pct == null ? <span title="Run an audit to check holders">—</span> : `${t.top10Pct.toFixed(1)}%`}
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-2">
                      <div className="flex h-1.5 w-12 overflow-hidden rounded-full bg-red-500/70" aria-hidden>
                        <div className="h-full bg-emerald-400" style={{ width: `${br * 100}%` }} />
                      </div>
                      <span className={br > 0.6 ? 'text-emerald-400' : br >= 0.5 ? 'text-slate-300' : 'text-red-500'}>
                        {t.buysH1}/{t.sellsH1}
                      </span>
                    </div>
                  </td>
                  <td className="px-3 py-2.5 pr-4">
                    <VerdictTag verdict={t.verdict} />
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </section>
  )
}

function TokenIdentity({
  token: t,
  selected,
  onSelect,
}: {
  token: ScoredToken
  selected: boolean
  onSelect: (t: ScoredToken) => void
}) {
  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation()
        onSelect(t)
      }}
      aria-pressed={selected}
      className="flex min-w-0 flex-1 items-center gap-2 text-left font-sans"
    >
      {t.imageUrl ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={t.imageUrl} alt="" className="size-6 shrink-0 rounded bg-slate-800 object-cover" loading="lazy" />
      ) : (
        <span className="flex size-6 shrink-0 items-center justify-center rounded bg-slate-800 text-[9px] text-slate-400">
          {t.symbol.slice(0, 2)}
        </span>
      )}
      <span className="min-w-0">
        <span className="block max-w-[140px] truncate font-medium text-slate-100">{t.symbol}</span>
        <span className="flex items-center gap-1 text-[10px] text-slate-500">
          <span aria-hidden className={cn('size-1.5 shrink-0 rounded-full', t.chain === 'solana' ? 'bg-violet-400' : 'bg-sky-400')} />
          <span className="font-mono" title={t.address}>
            {shortAddress(t.address)}
          </span>
        </span>
      </span>
    </button>
  )
}

function TokenCard({
  token: t,
  now,
  selected,
  onSelect,
}: {
  token: ScoredToken
  now: number
  selected: boolean
  onSelect: (t: ScoredToken) => void
}) {
  const vm = volMcRatio(t)
  const br = buyRatio(t.buysH1, t.sellsH1)
  return (
    <li className={cn('flex flex-col gap-3 px-4 py-3', selected && 'bg-emerald-500/5')}>
      <div className="flex items-center gap-2">
        <TokenIdentity token={t} selected={selected} onSelect={onSelect} />
        <VerdictTag verdict={t.verdict} />
      </div>
      <dl className="grid grid-cols-4 gap-2 font-mono text-[11px] tabular-nums">
        <Stat label="Age" value={formatAge(t.pairCreatedAt, now)} />
        <Stat label="MC" value={formatUsd(t.marketCap)} />
        <Stat
          label="Vol/MC"
          value={`${vm.toFixed(2)}x`}
          className={vm >= HIGH_SPEED_VOL_MC ? 'text-emerald-400' : undefined}
        />
        <Stat
          label="Buys"
          value={`${Math.round(br * 100)}%`}
          className={br > 0.6 ? 'text-emerald-400' : br < 0.5 ? 'text-red-500' : undefined}
        />
      </dl>
      <div className="flex gap-2">
        <CopyCaButton address={t.address} symbol={t.symbol} className="h-9 flex-1 justify-center text-xs" />
        <DexLink url={t.url} symbol={t.symbol} className="h-9 flex-1 justify-center text-xs" />
      </div>
    </li>
  )
}

function Stat({ label, value, className }: { label: string; value: string; className?: string }) {
  return (
    <div className="min-w-0">
      <dt className="font-sans text-[10px] text-slate-500">{label}</dt>
      <dd className={cn('truncate text-slate-200', className)}>{value}</dd>
    </div>
  )
}

function Segmented<T extends string>({
  label,
  value,
  onChange,
  options,
}: {
  label: string
  value: T
  onChange: (v: T) => void
  options: { value: T; label: string; icon?: React.ReactNode }[]
}) {
  return (
    <div role="radiogroup" aria-label={label} className="flex rounded-lg border border-slate-800 bg-slate-950 p-1">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          role="radio"
          aria-checked={value === o.value}
          onClick={() => onChange(o.value)}
          className={cn(
            'inline-flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium transition-colors',
            value === o.value ? 'bg-slate-800 text-slate-50' : 'text-slate-500 hover:text-slate-300',
          )}
        >
          {o.icon}
          {o.label}
        </button>
      ))}
    </div>
  )
}
